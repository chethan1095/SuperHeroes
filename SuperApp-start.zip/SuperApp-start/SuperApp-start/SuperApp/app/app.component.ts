import {Component} from 'angular2/core';
import {HeroListComponent} from'./avengers/hero-list.component';
import {WelcomeComponent} from './home/welcome.component'
import {ROUTER_PROVIDERS,RouteConfig,ROUTER_DIRECTIVES} from 'angular2/router';
import {HeroDetailComponent} from './avengers/hero-detail.component'

import {HeroService} from './hero.service';
import {HTTP_PROVIDERS} from 'angular2/http';
import 'rxjs/Rx';

@RouteConfig([
    {path:'/welcome',name:'Welcome',component:WelcomeComponent,useAsDefault:true},
    {path:'/heroes',name:'Heroes',component:HeroListComponent},
    {path:'/heroes/:id',name:'HeroDetail',component:HeroDetailComponent},
    {path:'/heroes/1',name:'HeroDetail1',component:HeroDetailComponent}
    
])

@Component({
    selector:"avenger-app",
    templateUrl:'app/app.component.html',
    directives:[ROUTER_DIRECTIVES],
    providers:[HeroService,HTTP_PROVIDERS,ROUTER_PROVIDERS]
})

export class AppComponent {
    pageTitle:string="Angular Avengers"

}