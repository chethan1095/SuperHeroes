import {Component,OnInit} from'angular2/core';
import {IHero} from '../avengers/hero'
import {HeroFilterPipe} from '../avengers/hero-pipe.component'
import {HeroService} from '../hero.service'
import {Http,Response} from 'angular2/http'
import {Observable} from 'rxjs/Observable'
import {ROUTER_DIRECTIVES} from 'angular2/router';
import {RouteParams,Router} from 'angular2/router'


@Component({
    selector:'super-heroes',
    templateUrl: 'app/home/welcome.component.html',
    directives:[ROUTER_DIRECTIVES],
    pipes:[HeroFilterPipe],
})
export class WelcomeComponent implements OnInit{
    public pageTitle: string = "Welcome";

constructor(private heroService:HeroService,private _routeParams:RouteParams,private _router:Router){}

heroes:IHero[];
errorMessage:string;

    ngOnInit():void{
        this.heroService.getHeroes()
        .subscribe(heroes=>this.heroes=heroes.slice(0,4),
        error=>this.errorMessage=<any>error);
    }
   
}