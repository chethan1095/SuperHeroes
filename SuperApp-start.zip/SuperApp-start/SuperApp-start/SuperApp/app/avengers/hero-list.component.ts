import {Component,OnInit} from'angular2/core';
import {IHero} from './hero'
import {HeroFilterPipe} from './hero-pipe.component'
import {HeroService} from '../hero.service'
import {Http,Response} from 'angular2/http'
import {Observable} from 'rxjs/Observable'
import {ROUTER_DIRECTIVES} from 'angular2/router';
import {RouteParams,Router} from 'angular2/router'


@Component({
    selector:'super-heroes',
    templateUrl:'./app/avengers/hero-list.component.html',
    styleUrls:['./app/avengers/hero-list.component.css'],
    pipes:[HeroFilterPipe],
    directives:[ROUTER_DIRECTIVES]
})
export class HeroListComponent implements OnInit{
    pageTitle:string="Hero List";

    constructor(private heroService:HeroService,private _routeParams:RouteParams,private _router:Router){}

imageWidth:number=100;
imageMargin:number=2;
showImage:boolean=false;
listFilter:string;
toggleImage():void{
    this.showImage =!this.showImage;
};

    heroes:IHero[];
    errorMessage:string;

    ngOnInit():void{
        console.log("this message is coming from life cycle hook...!");
        //this.heroes=this.heroService.getHeroes();
        this.heroService.getHeroes()
                        .subscribe(heroes=>this.heroes=heroes,
                        error=>this.errorMessage=<any>error);
    }    

   
}