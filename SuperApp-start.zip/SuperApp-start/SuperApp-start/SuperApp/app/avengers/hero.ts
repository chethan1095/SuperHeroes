export interface IHero{
    heroId: number;
    heroName: string;
    realName: string;
    heroStrength: string;
    heroNature: string;
    imageUrl:string;
}