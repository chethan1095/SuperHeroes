import {Component} from 'angular2/core';
import {HeroService} from '../hero.service';
import {IHero} from './hero'

import {RouteParams,Router} from 'angular2/router'

@Component({
    templateUrl:"app/avengers/hero-detail.component.html"
})

export class HeroDetailComponent{
 pageTitle:string="Hero Details";
 hero:IHero;
 errorMessage:string;

 constructor(private heroService:HeroService,private _routeParams:RouteParams,private _router:Router){
     let id=+this._routeParams.get('id');
 }

 ngOnInit() {
     if(!this.hero){
         let id=+this._routeParams.get('id');
         this.getHero(id);
     }
 }

 getHero(id:number){
     this.heroService.getHero(id)
         .subscribe(hero => this.hero= hero,
        error=>this.errorMessage=<any>error);
 }

 onBack():void{
     this._router.navigate(['Heroes']);
 }

 onBackWel():void{
     this._router.navigate(['Welcome']);
 }
}