import {Injectable} from 'angular2/core';
import {IHero} from './avengers/hero';

import {Http,Response} from 'angular2/http';
//import {} from "../api/heroes/data"
import {Observable} from 'rxjs/Observable'

@Injectable()

export class HeroService{

    // getHeroes():IHero[]{
    //     return [
    //         {
    //             "heroId": 1,
    //             "heroName": "Karna",
    //             "realName": "Vasusena ",
    //             "heroStrength": "Archery",
    //             "heroNature": "Generosity ",
    //             "imageUrl": "./app/assets/images/karna.jpg"
    //         },
    //         {
    //             "heroId": 2,
    //             "heroName": "Captain America",
    //             "realName": "Steven Rogers",
    //             "heroStrength": "Shield",
    //             "heroNature": "Confident",
    //             "imageUrl": "./app/assets/images/cap.jpg"
    //         },
    //         {
    //              "heroId": 3,
    //             "heroName": "Iron Man",
    //             "realName": "Tony Stark",
    //             "heroStrength": "Suit and Jarvis",
    //             "heroNature": "Stylish",
    //             "imageUrl": "./app/assets/images/IronMan.jpg"
    //         },
    //         {
    //             "heroId": 4,
    //             "heroName": "Thor",
    //             "realName": "Thor",
    //             "heroStrength": "Hammer",
    //             "heroNature": "Confused",
    //             "imageUrl": "./app/assets/images/thor.jpg"
    //         },
    //         {
    //             "heroId": 5,
    //             "heroName": "Hulk",
    //             "realName": "Bruce Banner",
    //             "heroStrength": "Size",
    //             "heroNature": "Angry",
    //             "imageUrl": "./app/assets/images/hulk.jpg"
    //         },
    //         {
    //             "heroId": 6,
    //             "heroName": "Black Widow ",
    //             "realName": "Agent Romanoff ",
    //             "heroStrength": "Mind Games",
    //             "heroNature": "Smart",
    //             "imageUrl": "./app/assets/images/blackwidow.jpg"
    //         },
    //          {
    //             "heroId": 7,
    //             "heroName": "Agent Fury",
    //             "realName": "Nick Fury",
    //             "heroStrength": "Nothing",
    //             "heroNature": "Serious",
    //             "imageUrl": "./app/assets/images/fury.jpg"
    //         }
    //     ]
    // }





    


private _dataUrl='https://my-json-server.typicode.com/chethan1095/SuperHeroes/HEROLIST';

constructor (private _http:Http){}

getHeroes():Observable<IHero[]>{
    return this._http.get(this._dataUrl)
               .map((response:Response)=> <IHero[]>response.json())
               .do(data=> console.log('All: '+JSON.stringify(data)))
               .catch(this.handleError);
}

getHero(id:number):Observable<IHero>{
    return (this.getHeroes()
             .map((Products:IHero[])=>Products
            .find(P=>P.heroId ===id)));
}

private handleError(error: Response){
    console.error(error);
    return Observable.throw(error.json().error || 'Server error');
}
}